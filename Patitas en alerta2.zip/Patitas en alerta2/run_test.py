#!/usr/bin/env python3
"""
Script para ejecutar todas las pruebas automáticamente
"""

import subprocess
import sys
import os

def run_tests():
    """Ejecuta todas las suites de pruebas"""
    print("🚀 Ejecutando Suite de Pruebas Completa")
    print("=" * 50)
    
    # Configurar variables de entorno para testing
    os.environ['FLASK_ENV'] = 'testing'
    
    tests = [
        ("Pruebas Unitarias", ["pytest", "tests/unit/", "-v", "--cov=app", "--cov=database"]),
        ("Pruebas de Integración", ["pytest", "tests/integration/", "-v"]),
        ("Pruebas Funcionales", ["pytest", "tests/functional/", "-v"]),
        ("Reporte de Cobertura", ["pytest", "--cov=app", "--cov-report=html"])
    ]
    
    all_passed = True
    
    for test_name, command in tests:
        print(f"\n📋 Ejecutando: {test_name}")
        print("-" * 30)
        
        try:
            result = subprocess.run(command, check=True)
            if result.returncode == 0:
                print(f"✅ {test_name} - PASÓ")
            else:
                print(f"❌ {test_name} - FALLÓ")
                all_passed = False
        except subprocess.CalledProcessError:
            print(f"❌ {test_name} - ERROR")
            all_passed = False
        except Exception as e:
            print(f"❌ {test_name} - EXCEPCIÓN: {e}")
            all_passed = False
    
    # Generar reporte final
    print("\n" + "=" * 50)
    if all_passed:
        print("🎉 ¡Todas las pruebas pasaron exitosamente!")
    else:
        print("⚠️  Algunas pruebas fallaron. Revisa los reportes.")
        sys.exit(1)

def run_specific_test(test_type):
    """Ejecuta un tipo específico de pruebas"""
    test_commands = {
        'unit': ['pytest', 'tests/unit/', '-v'],
        'integration': ['pytest', 'tests/integration/', '-v'],
        'functional': ['pytest', 'tests/functional/', '-v'],
        'all': ['pytest', 'tests/', '-v'],
        'coverage': ['pytest', '--cov=app', '--cov-report=term-missing']
    }
    
    if test_type in test_commands:
        subprocess.run(test_commands[test_type])
    else:
        print(f"Tipo de prueba no válido: {test_type}")

if __name__ == "__main__":
    if len(sys.argv) > 1:
        run_specific_test(sys.argv[1])
    else:
        run_tests()