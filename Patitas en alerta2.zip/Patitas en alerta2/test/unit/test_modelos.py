# tests/unit/test_modelos.py
import pytest

def test_importar_modelos():
    """Test que podemos importar los modelos"""
    try:
        from database import Foundation, AnimalReport, Notification
        print("✅ Modelos importados correctamente")
        assert True
    except ImportError as e:
        print(f"❌ Error importando modelos: {e}")
        pytest.skip("No se pueden importar los modelos")

def test_crear_fundacion(client):
    """Test crear una fundación básica"""
    try:
        from database import Foundation
        
        with client.application.app_context():
            fundacion = Foundation(
                name="Fundación de Prueba",
                email="test@fundacion.com", 
                address="Calle Test 123"
            )
            fundacion.set_password("testpassword")
            
            # Verificar que se creó correctamente
            assert fundacion.name == "Fundación de Prueba"
            assert fundacion.email == "test@fundacion.com"
            assert fundacion.check_password("testpassword") == True
            assert fundacion.check_password("wrongpassword") == False
            
            print("✅ Fundación creada correctamente")
            
    except Exception as e:
        print(f"⚠️  Error creando fundación: {e}")
        pytest.skip("No se pudo crear fundación")

def test_crear_reporte_animal(client):
    """Test crear un reporte de animal"""
    try:
        from database import AnimalReport
        
        with client.application.app_context():
            reporte = AnimalReport(
                animal_type="perro",
                latitude=4.710989,
                longitude=-74.072092,
                reporter_name="Juan Pérez",
                condition="Saludable"
            )
            
            # Verificar valores por defecto
            assert reporte.animal_type == "perro"
            assert reporte.status == "pendiente"  # Valor por defecto
            assert reporte.priority == "medio"    # Valor por defecto
            assert reporte.latitude == 4.710989
            
            print("✅ Reporte de animal creado correctamente")
            
    except Exception as e:
        print(f"⚠️  Error creando reporte: {e}")
        pytest.skip("No se pudo crear reporte")