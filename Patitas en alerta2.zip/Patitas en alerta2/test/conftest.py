# tests/conftest.py
import pytest
import os
import sys
from flask import Flask

# Añadir el directorio raíz al path
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

@pytest.fixture
def client():
    """Cliente de prueba básico para Flask"""
    try:
        # Intentar importar tu app real
        from app import app
        app.config['TESTING'] = True
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///:memory:'
        app.config['WTF_CSRF_ENABLED'] = False
        
        with app.test_client() as client:
            with app.app_context():
                from app import db
                db.create_all()
            yield client
            
    except ImportError as e:
        print(f"⚠️  No se pudo importar la app: {e}")
        # Crear app mínima para que los tests funcionen
        app = Flask(__name__)
        app.config['TESTING'] = True
        with app.test_client() as client:
            yield client