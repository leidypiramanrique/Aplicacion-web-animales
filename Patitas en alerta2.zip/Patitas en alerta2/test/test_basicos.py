# tests/test_basicos.py
# ESTOS TESTS DEBEN FUNCIONAR SIEMPRE

def test_matematicas_basicas():
    """Test que 1+1=2 - DEBE funcionar siempre"""
    print("🧪 Probando matemáticas básicas...")
    resultado = 1 + 1
    assert resultado == 2, f"1+1 debería ser 2, pero es {resultado}"

def test_strings_basicos():
    """Test de strings básicos"""
    print("🧪 Probando strings...")
    nombre = "Patitas en Alerta"
    assert "Patitas" in nombre
    assert len(nombre) > 5

def test_listas_basicas():
    """Test de listas básicas"""
    print("🧪 Probando listas...")
    animales = ["perro", "gato", "conejo"]
    assert len(animales) == 3
    assert "perro" in animales
    assert "gato" in animales

def test_verdadero_es_verdadero():
    """Test booleano básico"""
    print("🧪 Probando booleanos...")
    assert True is True
    assert False is False
    assert not False

def test_pytest_funciona():
    """Test que pytest está funcionando"""
    print("🧪 Probando pytest...")
    # Este test debe pasar SIEMPRE si pytest está instalado
    assert 2 * 2 == 4
    assert "hello".upper() == "HELLO"