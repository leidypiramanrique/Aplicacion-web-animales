# tests/integration/test_rutas.py
import pytest

def test_ruta_raiz(client):
    """Test que la ruta principal responde"""
    response = client.get('/')
    # Puede ser 200 o 302 (redirección)
    assert response.status_code in [200, 302]
    print(f"✅ Ruta / responde con código: {response.status_code}")

def test_ruta_login(client):
    """Test que la página de login carga"""
    response = client.get('/login')
    assert response.status_code == 200
    assert b'login' in response.data.lower() or b'iniciar' in response.data.lower()
    print("✅ Página de login carga correctamente")

def test_ruta_registro(client):
    """Test que la página de registro carga"""
    response = client.get('/register')
    assert response.status_code == 200
    print("✅ Página de registro carga correctamente")

def test_rutas_protegidas_redirigen(client):
    """Test que las rutas protegidas redirigen sin auth"""
    rutas_protegidas = ['/dashboard', '/profile', '/reports']
    
    for ruta in rutas_protegidas:
        response = client.get(ruta, follow_redirects=False)
        # Debería redirigir (302) o dar error (401/403)
        assert response.status_code in [302, 401, 403]
        print(f"✅ Ruta {ruta} correctamente protegida")