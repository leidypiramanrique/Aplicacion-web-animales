// Mapa interactivo para visualizar reportes
function initMap() {
    // Crear mapa
    const map = L.map('map').setView(mapCenter, 12);
    
    // Añadir capa de tiles
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);
    
    // Marcador de la fundación
    if (foundationData.latitude && foundationData.longitude) {
        const foundationMarker = L.marker([foundationData.latitude, foundationData.longitude])
            .addTo(map)
            .bindPopup(`
                <strong>${foundationData.name}</strong><br>
                ${foundationData.address || 'Sin dirección'}
            `)
            .openPopup();
    }
    
    // Marcadores de reportes
    reports.forEach(report => {
        let iconColor = report.animal_type === 'perro' ? 'blue' : 'green';
        let icon = L.divIcon({
            className: 'custom-icon',
            html: `<div style="background-color: ${iconColor}; width: 20px; height: 20px; border-radius: 50%;"></div>`,
            iconSize: [20, 20]
        });
        
        const reportMarker = L.marker([report.latitude, report.longitude], {icon: icon})
            .addTo(map)
            .bindPopup(`
                <strong>${report.animal_type === 'perro' ? '🐕 Perro' : '🐈 Gato'}</strong><br>
                Reportado: ${new Date(report.reported_at).toLocaleDateString()}<br>
                <a href="/dashboard" class="btn btn-sm btn-primary mt-2">Ver detalles</a>
            `);
    });
}

// Inicializar mapa cuando el documento esté listo
document.addEventListener('DOMContentLoaded', initMap);