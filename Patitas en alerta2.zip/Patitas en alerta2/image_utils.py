# image_utils.py
import os
import json
from flask import current_app
from PIL import Image
import uuid
import base64
from io import BytesIO
from datetime import datetime

class ImageProcessor:
    @staticmethod
    def allowed_file(filename):
        return '.' in filename and \
               filename.rsplit('.', 1)[1].lower() in {'jpg', 'jpeg', 'png', 'gif', 'webp'}
    
    @staticmethod
    def generate_filename(prefix='animal'):
        """Genera nombre único para archivos"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        unique_id = uuid.uuid4().hex[:8]
        return f"{prefix}_{unique_id}_{timestamp}"
    
    @staticmethod
    def optimize_image(image, max_size, format='JPEG', quality=85):
        """Optimiza imagen manteniendo proporciones"""
        img = Image.open(image)
        
        # Convertir a RGB si es necesario
        if img.mode in ('RGBA', 'P'):
            img = img.convert('RGB')
        
        # Redimensionar manteniendo aspecto
        img.thumbnail(max_size, Image.Resampling.LANCZOS)
        
        # Guardar en buffer
        buffer = BytesIO()
        img.save(buffer, format=format, quality=quality, optimize=True)
        buffer.seek(0)
        
        return buffer, img.size
    
    @staticmethod
    def save_image_versions(file, animal_type='unknown'):
        """Guarda múltiples versiones optimizadas"""
        filename = ImageProcessor.generate_filename(animal_type)
        upload_dir = os.path.join(current_app.root_path, 'static/uploads/animals')
        os.makedirs(upload_dir, exist_ok=True)
        
        versions = {}
        
        # 1. Versión display (800px) - Para detalles
        display_buffer, display_size = ImageProcessor.optimize_image(
            file, (800, 800), 'JPEG', 85
        )
        display_path = os.path.join(upload_dir, f"{filename}.jpg")
        with open(display_path, 'wb') as f:
            f.write(display_buffer.getvalue())
        versions['display'] = f"uploads/animals/{filename}.jpg"
        
        # 2. Thumbnail (300px) - Para listas
        file.seek(0)  # Reset file pointer
        thumb_buffer, thumb_size = ImageProcessor.optimize_image(
            file, (300, 300), 'JPEG', 85
        )
        thumb_path = os.path.join(upload_dir, f"{filename}_thumb.jpg")
        with open(thumb_path, 'wb') as f:
            f.write(thumb_buffer.getvalue())
        versions['thumbnail'] = f"uploads/animals/{filename}_thumb.jpg"
        
        # 3. Preview Base64 (150px) - Para carga rápida
        file.seek(0)
        preview_buffer, preview_size = ImageProcessor.optimize_image(
            file, (150, 150), 'JPEG', 60
        )
        preview_base64 = base64.b64encode(preview_buffer.getvalue()).decode('utf-8')
        versions['preview_base64'] = f"data:image/jpeg;base64,{preview_base64}"
        
        return versions