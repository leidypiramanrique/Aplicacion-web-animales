from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from datetime import datetime
import json

db = SQLAlchemy()

class User(UserMixin, db.Model):
    __tablename__ = 'user'
    
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    phone = db.Column(db.String(20))
    is_active = db.Column(db.Boolean, default=True)
    role = db.Column(db.String(20), default='user')  # 'user' o 'admin'
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relación con reportes
    reports = db.relationship('AnimalReport', backref='reporter', lazy=True, foreign_keys='AnimalReport.user_id')
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Foundation(UserMixin, db.Model):
    __tablename__ = 'foundation'
    
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password_hash = db.Column(db.String(200), nullable=False)
    address = db.Column(db.String(200))
    phone = db.Column(db.String(20))
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    description = db.Column(db.Text)
    capacity = db.Column(db.Integer)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Relación con reportes aceptados
    accepted_reports = db.relationship('AnimalReport', backref='foundation', lazy=True, foreign_keys='AnimalReport.foundation_id')
    notifications = db.relationship('Notification', backref='foundation', lazy=True)
    
    def set_password(self, password):
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        return check_password_hash(self.password_hash, password)
    
    def get_active_reports_count(self):
        return AnimalReport.query.filter_by(foundation_id=self.id, status='en_camino').count()

class AnimalReport(db.Model):
    __tablename__ = 'animal_report'
    
    id = db.Column(db.Integer, primary_key=True)
    animal_type = db.Column(db.String(10), nullable=False)
    photo_filename = db.Column(db.String(200))
    photo_versions = db.Column(db.Text)  # JSON con URLs
    preview_base64 = db.Column(db.Text)  # Miniatura base64
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    address = db.Column(db.String(200))
    reporter_name = db.Column(db.String(100))
    reporter_contact = db.Column(db.String(100))
    additional_notes = db.Column(db.Text)
    breed = db.Column(db.String(50))
    size = db.Column(db.String(10))
    condition = db.Column(db.String(100))
    status = db.Column(db.String(20), default='pendiente')
    priority = db.Column(db.String(10), default='medio')
    reported_at = db.Column(db.DateTime, default=datetime.utcnow)
    accepted_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    
    # Relaciones con usuarios y fundaciones
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'))  # Usuario que reportó
    foundation_id = db.Column(db.Integer, db.ForeignKey('foundation.id'))  # Fundación que aceptó
    
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    def set_photo(self, file):
        """Procesa y guarda la imagen con múltiples versiones"""
        from image_utils import ImageProcessor
        
        if file and ImageProcessor.allowed_file(file.filename):
            versions = ImageProcessor.save_image_versions(file, self.animal_type)
            
            self.photo_filename = versions['display'].split('/')[-1]
            self.photo_versions = json.dumps(versions)
            self.preview_base64 = versions['preview_base64']
    
    def get_photo_url(self, version='display'):
        """Obtiene URL de la imagen según versión necesaria"""
        if self.photo_versions:
            versions = json.loads(self.photo_versions)
            return versions.get(version, versions['display'])
        return None

class Notification(db.Model):
    __tablename__ = 'notification'
    
    id = db.Column(db.Integer, primary_key=True)
    foundation_id = db.Column(db.Integer, db.ForeignKey('foundation.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    related_report_id = db.Column(db.Integer, db.ForeignKey('animal_report.id'))