import os
import time
import subprocess

def kill_python_processes():
    """Cierra procesos de Python"""
    try:
        subprocess.run(['taskkill', '/F', '/IM', 'python.exe'], 
                      capture_output=True, text=True)
        print("✅ Procesos de Python terminados")
    except Exception as e:
        print(f"⚠️ No se pudieron terminar procesos: {e}")

def delete_database():
    """Elimina la base de datos"""
    db_files = [
        'animal_rescue.db',
        'instance/animal_rescue.db'
    ]
    
    for db_file in db_files:
        if os.path.exists(db_file):
            try:
                os.remove(db_file)
                print(f"✅ Eliminado: {db_file}")
            except PermissionError:
                print(f"❌ No se pudo eliminar: {db_file}")

if __name__ == '__main__':
    print("🧹 Limpiando sistema...")
    kill_python_processes()
    time.sleep(2)
    delete_database()
    print("🎉 Limpieza completada. Ahora puedes ejecutar app.py")