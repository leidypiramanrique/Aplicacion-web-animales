from flask import Flask, render_template, request, redirect, url_for, flash, jsonify
from flask_login import LoginManager, login_user, logout_user, login_required, current_user, UserMixin
from flask_socketio import SocketIO, emit
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime, timedelta
from geopy.distance import geodesic
import json
import math
import os
import time

# ================= CONFIGURACIÓN =================

basedir = os.path.abspath(os.path.dirname(__file__))
app = Flask(__name__)
app.config['SECRET_KEY'] = 'clave-secreta-rescate-animal-2024'
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(basedir, 'animal_rescue_new.db')}"  # Nuevo nombre
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)
socketio = SocketIO(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# ================= MODELOS =================

class User(UserMixin, db.Model):
    __tablename__ = 'user'
    id = db.Column(db.Integer, primary_key=True)
    full_name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    phone = db.Column(db.String(20))
    role = db.Column(db.String(20), default='user')
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    reports = db.relationship('AnimalReport', backref='user', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def get_id(self):
        return str(self.id)

class Foundation(UserMixin, db.Model):
    __tablename__ = 'foundation'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256))
    address = db.Column(db.String(200))
    phone = db.Column(db.String(20))
    latitude = db.Column(db.Float)
    longitude = db.Column(db.Float)
    description = db.Column(db.Text)
    capacity = db.Column(db.Integer, default=10)
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    accepted_reports = db.relationship('AnimalReport', backref='foundation', lazy=True)
    notifications = db.relationship('Notification', backref='foundation', lazy=True)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def get_id(self):
        return str(self.id)

    def get_active_reports_count(self):
        return AnimalReport.query.filter_by(
            foundation_id=self.id
        ).filter(
            AnimalReport.status.in_(['aceptado', 'en_camino'])
        ).count()

class AnimalReport(db.Model):
    __tablename__ = 'animal_report'
    id = db.Column(db.Integer, primary_key=True)
    animal_type = db.Column(db.String(50), default='perro')
    photo_filename = db.Column(db.String(200))
    photo_versions = db.Column(db.Text)
    preview_base64 = db.Column(db.Text)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    address = db.Column(db.String(200))
    reporter_name = db.Column(db.String(100))
    reporter_contact = db.Column(db.String(100))
    additional_notes = db.Column(db.Text)
    breed = db.Column(db.String(50))
    size = db.Column(db.String(20), default='mediano')
    condition = db.Column(db.String(100))
    status = db.Column(db.String(20), default='pendiente')
    priority = db.Column(db.String(20), default='medio')
    reported_at = db.Column(db.DateTime, default=datetime.utcnow)
    accepted_at = db.Column(db.DateTime)
    completed_at = db.Column(db.DateTime)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)
    foundation_id = db.Column(db.Integer, db.ForeignKey('foundation.id'))

    def set_photo(self, file):
        if file and file.filename:
            self.photo_filename = file.filename

    def get_status_display(self):
        status_map = {
            'pendiente': 'Pendiente',
            'aceptado': 'Aceptado',
            'en_camino': 'En Camino',
            'rescatado': 'Rescatado',
            'completado': 'Completado'
        }
        return status_map.get(self.status, self.status)

class Notification(db.Model):
    __tablename__ = 'notification'
    id = db.Column(db.Integer, primary_key=True)
    foundation_id = db.Column(db.Integer, db.ForeignKey('foundation.id'), nullable=False)
    message = db.Column(db.Text, nullable=False)
    related_report_id = db.Column(db.Integer, db.ForeignKey('animal_report.id'))
    is_read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# ================= FUNCIONES AUXILIARES =================

@login_manager.user_loader
def load_user(user_id):
    user = Foundation.query.get(int(user_id))
    if user:
        return user
    return User.query.get(int(user_id))

def calculate_distance(lat1, lon1, lat2, lon2):
    try:
        return geodesic((lat1, lon1), (lat2, lon2)).km
    except:
        R = 6371
        dlat = math.radians(lat2 - lat1)
        dlon = math.radians(lon2 - lon1)
        a = math.sin(dlat/2) * math.sin(dlat/2) + math.cos(math.radians(lat1)) * math.cos(math.radians(lat2)) * math.sin(dlon/2) * math.sin(dlon/2)
        c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
        return R * c

def create_notification(foundation_id, message, report_id=None):
    notification = Notification(
        foundation_id=foundation_id,
        message=message,
        related_report_id=report_id
    )
    db.session.add(notification)
    db.session.commit()
    
    try:
        socketio.emit('new_notification', {
            'message': message,
            'foundation_id': foundation_id
        }, room=f'foundation_{foundation_id}')
    except:
        pass

# ================= INICIALIZACIÓN SEGURA =================

def initialize_database():
    """Inicializa la base de datos de forma segura"""
    with app.app_context():
        print("🔄 Inicializando base de datos...")
        
        # Crear todas las tablas
        db.create_all()
        print("✅ Tablas creadas")
        
        # Verificar si ya existen datos
        if User.query.first() is None:
            print("🗃️ Creando datos de ejemplo...")
            
            # Crear usuario administrador
            admin_user = User(
                full_name='Administrador del Sistema',
                email='admin@rescate.com',
                phone='+57 1 0000000',
                role='admin'
            )
            admin_user.set_password('admin123')
            db.session.add(admin_user)
            
            # Crear usuario normal
            normal_user = User(
                full_name='Usuario de Prueba',
                email='usuario@ejemplo.com',
                phone='+57 1 1234567'
            )
            normal_user.set_password('password123')
            db.session.add(normal_user)
            
            # Crear fundaciones de ejemplo
            foundation1 = Foundation(
                name='Fundación Patitas Salvadas',
                email='fundacion@ejemplo.com',
                address='Carrera 15 #85-25, Bogotá',
                phone='+57 1 3456789',
                latitude=4.669194,
                longitude=-74.056595,
                description='Fundación dedicada al rescate y cuidado de animales en situación de calle en Bogotá',
                capacity=30
            )
            foundation1.set_password('password123')
            db.session.add(foundation1)
            
            foundation2 = Foundation(
                name='Refugio Animal Amor Incondicional',
                email='fundacion2@ejemplo.com',
                address='Calle 72 #12-35, Bogotá',
                phone='+57 1 4567890',
                latitude=4.658811,
                longitude=-74.060194,
                description='Refugio especializado en rescate y rehabilitación de animales maltratados',
                capacity=25
            )
            foundation2.set_password('password123')
            db.session.add(foundation2)
            
            # Crear algunos reportes de ejemplo
            report1 = AnimalReport(
                animal_type='perro',
                latitude=4.669194,
                longitude=-74.056595,
                address='Carrera 15 #85-20, Bogotá',
                breed='Criollo',
                size='mediano',
                condition='Herido en pata trasera',
                additional_notes='Se ve asustado pero no agresivo',
                priority='alto',
                user_id=normal_user.id,
                reporter_name=normal_user.full_name,
                reporter_contact=normal_user.phone
            )
            db.session.add(report1)
            
            report2 = AnimalReport(
                animal_type='gato',
                latitude=4.658811,
                longitude=-74.060194,
                address='Calle 72 #12-30, Bogotá',
                breed='Siamés',
                size='pequeño',
                condition='Desnutrido pero alerta',
                additional_notes='Es muy amigable, se acerca a las personas',
                priority='medio',
                user_id=normal_user.id,
                reporter_name=normal_user.full_name,
                reporter_contact=normal_user.phone
            )
            db.session.add(report2)
            
            db.session.commit()
            print("✅ Datos de ejemplo creados exitosamente!")
        else:
            print("ℹ️ La base de datos ya contiene datos")

# ================= RUTAS =================

@app.route('/')
def index():
    if current_user.is_authenticated:
        if hasattr(current_user, 'role') and current_user.role == 'user':
            return redirect(url_for('user_dashboard'))
        else:
            return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        user = Foundation.query.filter_by(email=email, is_active=True).first()
        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('dashboard'))
        
        user = User.query.filter_by(email=email, is_active=True).first()
        if user and user.check_password(password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('user_dashboard'))
        
        flash('Email o contraseña incorrectos', 'error')
    
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('Has cerrado sesión correctamente', 'success')
    return redirect(url_for('login'))

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    return render_template('register.html')

@app.route('/register/user', methods=['GET', 'POST'])
def register_user():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        full_name = request.form['full_name']
        email = request.form['email']
        password = request.form['password']
        phone = request.form.get('phone', '')
        
        if User.query.filter_by(email=email).first() or Foundation.query.filter_by(email=email).first():
            flash('Ya existe una cuenta con este email', 'error')
            return render_template('register_user.html')
        
        user = User(
            full_name=full_name,
            email=email,
            phone=phone
        )
        user.set_password(password)
        
        db.session.add(user)
        db.session.commit()
        
        flash('Registro exitoso. Ya puedes iniciar sesión.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register_user.html')

@app.route('/register/foundation', methods=['GET', 'POST'])
def register_foundation():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        address = request.form['address']
        phone = request.form['phone']
        
        if Foundation.query.filter_by(email=email).first() or User.query.filter_by(email=email).first():
            flash('Ya existe una cuenta con este email', 'error')
            return render_template('register_foundation.html')
        
        foundation = Foundation(
            name=name,
            email=email,
            address=address,
            phone=phone
        )
        foundation.set_password(password)
        
        db.session.add(foundation)
        db.session.commit()
        
        flash('Registro exitoso. Ya puedes iniciar sesión.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register_foundation.html')

@app.route('/user/dashboard')
@login_required
def user_dashboard():
    if not hasattr(current_user, 'role') or current_user.role != 'user':
        flash('Acceso no autorizado', 'error')
        return redirect(url_for('dashboard'))
    
    user_reports = AnimalReport.query.filter_by(user_id=current_user.id).order_by(AnimalReport.reported_at.desc()).all()
    
    stats = {
        'total': len(user_reports),
        'pending': len([r for r in user_reports if r.status == 'pendiente']),
        'in_progress': len([r for r in user_reports if r.status in ['aceptado', 'en_camino']]),
        'completed': len([r for r in user_reports if r.status in ['rescatado', 'completado']])
    }
    
    return render_template('user_dashboard.html', 
                         reports=user_reports, 
                         stats=stats, 
                         user=current_user)

@app.route('/user/new-report', methods=['GET', 'POST'])
@login_required
def user_new_report():
    if not hasattr(current_user, 'role') or current_user.role != 'user':
        flash('Acceso no autorizado', 'error')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        try:
            animal_type = request.form.get('animal_type', 'perro')
            latitude = float(request.form.get('latitude', 0))
            longitude = float(request.form.get('longitude', 0))
            address = request.form.get('address', '')
            breed = request.form.get('breed', '')
            size = request.form.get('size', 'mediano')
            condition = request.form.get('condition', '')
            additional_notes = request.form.get('additional_notes', '')
            priority = request.form.get('priority', 'medio')
            
            new_report = AnimalReport(
                animal_type=animal_type,
                latitude=latitude,
                longitude=longitude,
                address=address,
                breed=breed,
                size=size,
                condition=condition,
                additional_notes=additional_notes,
                priority=priority,
                user_id=current_user.id,
                reporter_name=current_user.full_name,
                reporter_contact=current_user.phone or current_user.email
            )
            
            if 'photo' in request.files:
                file = request.files['photo']
                if file and file.filename != '':
                    new_report.set_photo(file)
            
            db.session.add(new_report)
            db.session.commit()
            
            foundations = Foundation.query.filter_by(is_active=True).all()
            for foundation in foundations:
                if foundation.latitude and foundation.longitude:
                    distance = calculate_distance(
                        foundation.latitude, foundation.longitude,
                        new_report.latitude, new_report.longitude
                    )
                    if distance < 50:
                        create_notification(
                            foundation.id,
                            f'Nuevo reporte de {new_report.animal_type} a {distance:.1f}km',
                            new_report.id
                        )
            
            flash('Reporte creado exitosamente. Las fundaciones cercanas han sido notificadas.', 'success')
            return redirect(url_for('user_dashboard'))
            
        except Exception as e:
            flash(f'Error al crear el reporte: {str(e)}', 'error')
    
    return render_template('user_new_report.html')

@app.route('/dashboard')
@login_required
def dashboard():
    if hasattr(current_user, 'role') and current_user.role == 'user':
        return redirect(url_for('user_dashboard'))
    
    animal_filter = request.args.get('filter', 'all')
    
    total_reports = AnimalReport.query.count()
    pending_reports = AnimalReport.query.filter_by(status='pendiente').count()
    active_reports = current_user.get_active_reports_count()
    completed_reports = AnimalReport.query.filter_by(foundation_id=current_user.id, status='rescatado').count()
    
    recent_reports = AnimalReport.query.filter(
        AnimalReport.reported_at >= datetime.utcnow() - timedelta(days=7)
    ).count()
    
    query = AnimalReport.query.filter_by(status='pendiente')
    
    if animal_filter == 'perro':
        query = query.filter_by(animal_type='perro')
    elif animal_filter == 'gato':
        query = query.filter_by(animal_type='gato')
    elif animal_filter == 'urgente':
        query = query.filter_by(priority='alto')
    
    reports = query.all()
    
    if current_user.latitude and current_user.longitude:
        reports_with_distance = []
        for report in reports:
            distance = calculate_distance(
                current_user.latitude, current_user.longitude,
                report.latitude, report.longitude
            )
            reports_with_distance.append((report, distance))
        
        reports_with_distance.sort(key=lambda x: x[1])
        reports = [report for report, distance in reports_with_distance][:9]
    
    unread_notifications = Notification.query.filter_by(
        foundation_id=current_user.id, 
        is_read=False
    ).count()
    
    return render_template('dashboard.html', 
                         reports=reports,
                         foundation=current_user,
                         stats={
                             'total': total_reports,
                             'pending': pending_reports,
                             'active': active_reports,
                             'completed': completed_reports,
                             'recent': recent_reports
                         },
                         unread_notifications=unread_notifications)

@app.errorhandler(404)
def not_found_error(error):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(error):
    db.session.rollback()
    return render_template('500.html'), 500

# ================= INICIALIZACIÓN PRINCIPAL =================

if __name__ == '__main__':
    # Inicializar la base de datos
    initialize_database()
    
    print("\n" + "="*50)
    print("🌐 SERVICIO DE RESCATE ANIMAL")
    print("="*50)
    print("📧 CREDENCIALES DE PRUEBA:")
    print("   👤 Administrador: admin@rescate.com / admin123")
    print("   👤 Usuario normal: usuario@ejemplo.com / password123")
    print("   🏢 Fundación 1: fundacion@ejemplo.com / password123")
    print("   🏢 Fundación 2: fundacion2@ejemplo.com / password123")
    print("="*50)
    print("🚀 Servidor iniciado en: http://localhost:5000")
    print("="*50)
    
    # Ejecutar la aplicación
    try:
        socketio.run(app, debug=True, host='0.0.0.0', port=5000, allow_unsafe_werkzeug=True)
    except Exception as e:
        print(f"⚠️ SocketIO no disponible: {e}")
        app.run(debug=True, host='0.0.0.0', port=5000)